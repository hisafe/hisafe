package capsis.lib.cstability.function.util;

/**
 * ZeroVariable of the model C-STABILITY.
 * 
 * @author J. Sainte-Marie, F. de Coligny - February 2021
 */
public class ZeroVariable extends Variables {

	/**
	 * Constructor
	 */
	public ZeroVariable() {

	}

}
