package capsis.lib.cstability.function.interfaces;

import java.util.List;

import capsis.lib.cstability.function.util.Availability;

public interface Available {

	public List<Availability> getAvailabilities();
}
