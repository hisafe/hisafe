# This script launches C-STABILITY under Linux or MacOSX
# Requires Java 1.8

java -jar cstability.jar $*


